﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Холодкова
{
    public partial class Form2 : Form
    {
        string connectionString = "Host=localhost;Port=5432;Database=demo_holod;Username=postgres;Password=998877fff;";
        public Form2()
        {
            InitializeComponent();
            LoadMaterialsToPanels();
        }
        private void LoadMaterialsToPanels()
        {
            panel1.Controls.Clear();

            using (var conn = new NpgsqlConnection(connectionString))
            {
                conn.Open();
                using (var cmd = new NpgsqlCommand(@"
                    SELECT m.material_id, m.nazvanie, tm.nazvanie as tip_materiala, 
                           m.minimalnoe_kolichestvo, m.kolichestvo_na_sklade, 
                           m.tsena_za_edinitsu, ei.oboznachenie
                    FROM materialy m
                    JOIN tipy_materialov tm ON m.tip_materiala_id = tm.tip_materiala_id
                    JOIN edinitsy_izmereniya ei ON m.edinitsa_id = ei.edinitsa_id", conn))
                using (var reader = cmd.ExecuteReader())
                {
                    int topPadding = 10; 
                    int bottomPadding = 10; 
                    int yOffset = topPadding; 
                    while (reader.Read())
                    {
                        var materialPanel = new Panel
                        {
                            Size = new Size(panel1.Width - 35, 145),
                            Location = new Point(10, yOffset),
                            BorderStyle = BorderStyle.FixedSingle,
                            Tag = reader.GetInt32(0) // material_id
                        };

                        // Расчет стоимости минимальной партии
                        decimal minQty = reader.GetDecimal(3);
                        decimal currentQty = reader.GetDecimal(4);
                        decimal price = reader.GetDecimal(5);
                        string unit = reader.GetString(6);
                        decimal packageQty = GetPackageQuantity(reader.GetInt32(0));

                        decimal cost = 0;
                        if (currentQty < minQty)
                        {
                            decimal neededQty = minQty - currentQty;
                            decimal packages = Math.Ceiling(neededQty / packageQty);
                            cost = packages * packageQty * price;
                        }

                        var labelMain = new Label
                        {
                            Text = $"Тип: {reader.GetString(2)}|" +
                                   $"Наименование: {reader.GetString(1)}\n" +
                                   $"Минимальное количество: {minQty} {unit}\n" +
                                   $"Количество на складе: {currentQty} {unit}\n" +
                                   $"Цена: {price:F2} р / {unit}",
                            AutoSize = true,
                            Location = new Point(5, 5) 
                        };

                        
                        var labelCost = new Label
                        {
                            Text = currentQty < minQty ? $"Стоимость партии: {cost:F2} р" : "Минимальная партия не требуется",
                            AutoSize = true,
                            Location = new Point(materialPanel.Width - 5 - 360, labelMain.Top + 40) 
                        };


                        // Добавление меток на панель
                        materialPanel.Controls.Add(labelMain);
                        materialPanel.Controls.Add(labelCost);
                        panel1.Controls.Add(materialPanel);
                        yOffset += materialPanel.Height + 10; 


                        // Обработчик клика для редактирования
                        materialPanel.Click += (s, e) =>
                        {
                            using (var editForm = new Form3((s as Panel).Tag as int?))
                            {
                                editForm.ShowDialog();
                                LoadMaterialsToPanels(); // Обновление после закрытия формы редактирования
                            }
                        };
                    }
                }
            }
        }

        private decimal GetPackageQuantity(int materialId)
        {
            using (var conn = new NpgsqlConnection(connectionString))
            {
                conn.Open();
                using (var cmd = new NpgsqlCommand("SELECT kolichestvo_v_upakovke FROM materialy WHERE material_id = @id", conn))
                {
                    cmd.Parameters.AddWithValue("@id", materialId);
                    var result = cmd.ExecuteScalar();
                    return result != DBNull.Value ? Convert.ToDecimal(result) : 1;
                }
            }
        }


       
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();
            f3.Show();
            this.Hide();    
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }
    }
}
