﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Холодкова
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (var con = new NpgsqlConnection("Host=localhost;Port=5432;Database=pol;Username=postgres;Password=998877fff"))
            {

                con.Open();
                var cmd = new NpgsqlCommand("Select 1 from sotrudniki where login=@l and password=@p", con);

                cmd.Parameters.AddWithValue("@l", textBox1.Text.Trim());
                cmd.Parameters.AddWithValue("@p", textBox2.Text.Trim());
                if (cmd.ExecuteScalar() != null) { Form1 f1 = new Form1(); f1.Show(); this.Hide(); }
                else { MessageBox.Show("Error"); }

            }
        }
    }
}
