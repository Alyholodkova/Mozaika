﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Холодкова
{
    public partial class Form3 : Form
    {
        private int? materialId;
        string connectionString = "Host=localhost;Port=5432;Username=postgres;Password=998877fff;Database=demo_holod;";
        public Form3(int? id = null)
        {
            InitializeComponent();
            materialId = id;
            Text = materialId == null ? "Добавить" : "Изменить";

            if (materialId != null)
                LoadMaterial();

            LoadData(); // Загрузка данных для комбобоксов

        }
        private void LoadMaterial()
        {
            using (var conn = new NpgsqlConnection(connectionString))
            {
                conn.Open();
                var cmd = new NpgsqlCommand($"SELECT * FROM materialy WHERE material_id = @materialId", conn);
                cmd.Parameters.AddWithValue("materialId", materialId.Value);
                
                using (var reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        textBox1.Text = reader["nazvanie"].ToString();
                        textBox2.Text = reader["tsena_za_edinitsu"].ToString();
                        textBox3.Text = reader["kolichestvo_na_sklade"].ToString();
                        textBox4.Text = reader["minimalnoe_kolichestvo"].ToString();
                        textBox5.Text = reader["kolichestvo_v_upakovke"]?.ToString();
                        comboBox1.SelectedValue = reader["tip_materiala_id"];
                        comboBox2.SelectedValue = reader["postavshchik_id"];
                        comboBox3.SelectedValue = reader["edinitsa_id"];
                    }
                }
            }
        }

        private void LoadData()
        {
            LoadTipMateriala();
            LoadPostavshchiki();
            LoadEdinitsyIzmereniya();
        }

        private void LoadTipMateriala()
        {
            using (NpgsqlConnection connection = new NpgsqlConnection(connectionString))
            {
                string query = "SELECT tip_materiala_id, nazvanie FROM tipy_materialov";
                NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(query, connection);
                DataSet dataSet = new DataSet();
                adapter.Fill(dataSet, "TipMateriala");

                comboBox1.DataSource = dataSet.Tables["TipMateriala"];
                comboBox1.DisplayMember = "nazvanie";
                comboBox1.ValueMember = "tip_materiala_id";
                comboBox1.SelectedIndex = -1; 
            }
        }

        private void LoadPostavshchiki()
        {
            using (NpgsqlConnection connection = new NpgsqlConnection(connectionString))
            {
                string query = "SELECT postavshchik_id, nazvanie FROM postavshchiki";
                NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(query, connection);
                DataSet dataSet = new DataSet();
                adapter.Fill(dataSet, "Postavshchiki");

                comboBox2.DataSource = dataSet.Tables["Postavshchiki"];
                comboBox2.DisplayMember = "nazvanie";
                comboBox2.ValueMember = "postavshchik_id";
                comboBox2.SelectedIndex = -1; 
            }
        }

        private void LoadEdinitsyIzmereniya()
        {
            using (NpgsqlConnection connection = new NpgsqlConnection(connectionString))
            {
                string query = "SELECT edinitsa_id, nazvanie FROM edinitsy_izmereniya";
                NpgsqlDataAdapter adapter = new NpgsqlDataAdapter(query, connection);
                DataSet dataSet = new DataSet();
                adapter.Fill(dataSet, "EdinitsyIzmereniya");

                comboBox3.DataSource = dataSet.Tables["EdinitsyIzmereniya"];
                comboBox3.DisplayMember = "nazvanie";
                comboBox3.ValueMember = "edinitsa_id";
                comboBox3.SelectedIndex = -1; 
            }
        }


        private void Form3_Load(object sender, EventArgs e)
        {
        

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(textBox1.Text) ||
                    string.IsNullOrEmpty(textBox2.Text) ||
                    string.IsNullOrEmpty(textBox3.Text) ||
                    string.IsNullOrEmpty(textBox4.Text) ||
                    comboBox1.SelectedValue == null ||
                    comboBox2.SelectedValue == null ||
                    comboBox3.SelectedValue == null)
                {
                    MessageBox.Show("Пожалуйста, заполните все поля.");
                    return;
                }

                //  "InvariantCulture" для разбора цен.
                decimal price;
                if (!decimal.TryParse(textBox2.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out price))
                {
                    MessageBox.Show("Ошибка: неверный формат цены.");
                    return;
                }

                decimal quantityOnStock;
                if (!decimal.TryParse(textBox3.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out quantityOnStock))
                {
                    MessageBox.Show("Ошибка: неверный формат количества на складе.");
                    return;
                }

                decimal minimumQuantity;
                if (!decimal.TryParse(textBox4.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out minimumQuantity))
                {
                    MessageBox.Show("Ошибка: неверный формат минимального количества.");
                    return;
                }

                decimal? packageQtyValue = string.IsNullOrEmpty(textBox5.Text) ? (decimal?)null : Convert.ToDecimal(textBox5.Text, CultureInfo.InvariantCulture);

                string sql = materialId == null ?
                    "INSERT INTO materialy (nazvanie, tsena_za_edinitsu, kolichestvo_na_sklade, minimalnoe_kolichestvo, kolichestvo_v_upakovke, tip_materiala_id, postavshchik_id, edinitsa_id) " +
                    "VALUES (@nazvanie, @tsena, @kolichestvo_na_sklade, @minimalnoe_kolichestvo, @kolichestvo_v_upakovke, @tip_materiala_id, @postavshchik_id, @edinitsa_id)" :
                    "UPDATE materialy SET nazvanie=@nazvanie, tsena_za_edinitsu=@tsena, kolichestvo_na_sklade=@kolichestvo_na_sklade, " +
                    "minimalnoe_kolichestvo=@minimalnoe_kolichestvo, kolichestvo_v_upakovke=@kolichestvo_v_upakovke, tip_materiala_id=@tip_materiala_id, postavshchik_id=@postavshchik_id, edinitsa_id=@edinitsa_id " +
                    "WHERE material_id=@material_id";

                using (var conn = new NpgsqlConnection(connectionString))
                {
                    conn.Open();
                    using (var cmd = new NpgsqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("nazvanie", textBox1.Text);
                        cmd.Parameters.AddWithValue("tsena", price);
                        cmd.Parameters.AddWithValue("kolichestvo_na_sklade", quantityOnStock);
                        cmd.Parameters.AddWithValue("minimalnoe_kolichestvo", minimumQuantity);
                        cmd.Parameters.AddWithValue("kolichestvo_v_upakovke", (object)packageQtyValue ?? DBNull.Value);
                        cmd.Parameters.AddWithValue("tip_materiala_id", Convert.ToInt32(comboBox1.SelectedValue));
                        cmd.Parameters.AddWithValue("postavshchik_id", Convert.ToInt32(comboBox2.SelectedValue));
                        cmd.Parameters.AddWithValue("edinitsa_id", Convert.ToInt32(comboBox3.SelectedValue));

                        if (materialId != null)
                        {
                            cmd.Parameters.AddWithValue("material_id", materialId.Value);
                        }

                        cmd.ExecuteNonQuery();
                    }
                }

                DialogResult = DialogResult.OK;
                MessageBox.Show($"Успешно! Добавлено!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
      


    }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Show();
            this.Hide();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
